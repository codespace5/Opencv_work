# PoolTable

Python code to identify pool balls on a table from screenshots of matches. Currently is able to transform oblique images to an overhead view, identify balls and circle them.

## To Do

* Identify balls on the rail
* Identify clusters
* Identify balls by their color
* Return the centroid of each ball
* Plot the balls on a table layout
* ~~Refactor the table bed and ball ID code to remove overlap~~



